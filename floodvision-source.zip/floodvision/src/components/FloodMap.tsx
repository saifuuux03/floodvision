import { useEffect, useState } from "react";
import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { SampleLocation } from "@/lib/sample-data";
import type { RiskLevel } from "@/lib/flood-analysis";

function useRiskColors() {
  const [colors, setColors] = useState<Record<RiskLevel, string>>({ High: "#d33", Medium: "#e90", Low: "#2a8" });
  useEffect(() => {
    const s = getComputedStyle(document.documentElement);
    setColors({
      High: s.getPropertyValue("--risk-high").trim() || "#d33",
      Medium: s.getPropertyValue("--risk-medium").trim() || "#e90",
      Low: s.getPropertyValue("--risk-low").trim() || "#2a8",
    });
  }, []);
  return colors;
}

export default function FloodMap({
  locations,
  center,
  selectedId,
  onSelect,
  height = 520,
}: {
  locations: SampleLocation[];
  center: [number, number];
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  height?: number;
}) {
  const colors = useRiskColors();
  return (
    <MapContainer center={center} zoom={13} scrollWheelZoom style={{ height, width: "100%" }}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {locations.map((l) => (
        <CircleMarker
          key={l.id}
          center={[l.lat, l.lng]}
          radius={selectedId === l.id ? 18 : 8 + l.waterCoverage / 8}
          pathOptions={{ color: colors[l.risk], fillColor: colors[l.risk], fillOpacity: 0.45, weight: selectedId === l.id ? 4 : 2 }}
          eventHandlers={{ click: () => onSelect?.(l.id) }}
        >
          <Tooltip direction="top" offset={[0, -6]} permanent={selectedId === l.id}>
            {l.name}
          </Tooltip>
          <Popup>
            <strong>{l.name}</strong>
            <br />
            Risk: {l.risk} · Water: {l.waterCoverage}%
            <br />
            <em>Sample location for demonstration — not real data.</em>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
