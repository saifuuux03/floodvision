import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { RiskBadge } from "./RiskBadge";
import type { SampleLocation } from "@/lib/sample-data";

export function PriorityTable({ locations }: { locations: SampleLocation[] }) {
  const sorted = [...locations].sort((a, b) => a.priority - b.priority);
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">#</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Risk</TableHead>
            <TableHead className="text-right">Water</TableHead>
            <TableHead className="hidden text-right sm:table-cell">Est. residents</TableHead>
            <TableHead className="hidden md:table-cell">Note</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sorted.map((l) => (
            <TableRow key={l.id}>
              <TableCell className="font-mono font-semibold text-primary">{l.priority}</TableCell>
              <TableCell className="font-medium">{l.name}</TableCell>
              <TableCell>
                <RiskBadge risk={l.risk} />
              </TableCell>
              <TableCell className="text-right font-mono">{l.waterCoverage}%</TableCell>
              <TableCell className="hidden text-right font-mono sm:table-cell">
                {l.population.toLocaleString("en-IN")}
              </TableCell>
              <TableCell className="hidden text-muted-foreground md:table-cell">{l.note}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
