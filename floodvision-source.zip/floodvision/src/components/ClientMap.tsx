import { ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense, type ComponentProps } from "react";

const FloodMap = lazy(() => import("./FloodMap"));

export function ClientMap(props: ComponentProps<typeof FloodMap>) {
  const h = props.height ?? 520;
  const fallback = <div className="grid w-full animate-pulse place-items-center bg-secondary text-sm text-muted-foreground" style={{ height: h }}>Loading map…</div>;
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <FloodMap {...props} />
      </Suspense>
    </ClientOnly>
  );
}
