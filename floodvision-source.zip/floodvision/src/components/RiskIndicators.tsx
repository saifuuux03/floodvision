import { RISK_THRESHOLDS, type RiskLevel } from "@/lib/flood-analysis";
import { cn } from "@/lib/utils";
import { AlertTriangle, AlertCircle, CheckCircle2 } from "lucide-react";

const items: { level: RiskLevel; icon: typeof AlertTriangle; rule: string; action: string; tone: string }[] = [
  { level: "High", icon: AlertTriangle, rule: `≥ ${RISK_THRESHOLDS.high}% water`, action: "Respond first", tone: "bg-risk-high-soft text-risk-high" },
  { level: "Medium", icon: AlertCircle, rule: `${RISK_THRESHOLDS.medium}–${RISK_THRESHOLDS.high - 1}% water`, action: "Monitor closely", tone: "bg-risk-medium-soft text-risk-medium" },
  { level: "Low", icon: CheckCircle2, rule: `< ${RISK_THRESHOLDS.medium}% water`, action: "Routine checks", tone: "bg-risk-low-soft text-risk-low" },
];

export function RiskIndicators({ counts }: { counts?: Record<RiskLevel, number> }) {
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      {items.map(({ level, icon: Icon, rule, action, tone }) => (
        <div key={level} className={cn("flex items-center gap-3 rounded-xl p-4", tone)}>
          <Icon className="size-8 shrink-0" />
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-2">
              <p className="font-display text-lg font-bold">{level} risk</p>
              {counts && <p className="font-mono text-2xl font-bold">{counts[level]}</p>}
            </div>
            <p className="text-xs font-medium opacity-80">
              {rule} · {action}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
