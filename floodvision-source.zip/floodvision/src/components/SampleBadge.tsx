import { FlaskConical } from "lucide-react";
import { cn } from "@/lib/utils";

export function SampleBadge({ className, label = "Sample data" }: { className?: string; label?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-sample px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-sample-foreground",
        className,
      )}
    >
      <FlaskConical className="size-3" />
      {label}
    </span>
  );
}
