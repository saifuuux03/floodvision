import { cn } from "@/lib/utils";
import type { RiskLevel } from "@/lib/flood-analysis";

const styles: Record<RiskLevel, string> = {
  High: "bg-risk-high-soft text-risk-high border-risk-high/30",
  Medium: "bg-risk-medium-soft text-risk-medium border-risk-medium/30",
  Low: "bg-risk-low-soft text-risk-low border-risk-low/30",
};
const dots: Record<RiskLevel, string> = {
  High: "bg-risk-high",
  Medium: "bg-risk-medium",
  Low: "bg-risk-low",
};

export function RiskBadge({ risk, className }: { risk: RiskLevel; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        styles[risk],
        className,
      )}
    >
      <span className={cn("size-1.5 rounded-full", dots[risk])} />
      {risk}
    </span>
  );
}

export function riskDotClass(risk: RiskLevel) {
  return dots[risk];
}
