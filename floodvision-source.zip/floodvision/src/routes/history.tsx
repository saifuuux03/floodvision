import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Trash2, ScanSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageHeader } from "@/components/PageHeader";
import { RiskBadge } from "@/components/RiskBadge";
import { useHistory, removeAnalysis, clearHistory } from "@/lib/history-store";
import type { AnalysisResult } from "@/lib/flood-analysis";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Analysis History – FloodVision" },
      { name: "description", content: "Review past drone image analyses with water coverage, risk level and segmentation images." },
      { property: "og:title", content: "Analysis History – FloodVision" },
      { property: "og:description", content: "Past drone image analyses with water coverage and risk level." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HistoryPage,
});

function fmt(iso: string) {
  return new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
}

function HistoryPage() {
  const items = useHistory();
  const [open, setOpen] = useState<AnalysisResult | null>(null);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-10">
      <PageHeader
        eyebrow="History"
        title="Analysis history"
        description="Your last 12 analyses, saved in this browser only."
        actions={
          items.length > 0 && (
            <Button variant="outline" onClick={() => { if (confirm("Delete all saved analyses?")) clearHistory(); }}>
              <Trash2 /> Clear all
            </Button>
          )
        }
      />

      {items.length === 0 ? (
        <Card>
          <CardContent className="grid place-items-center p-12 text-center">
            <ScanSearch className="size-10 text-muted-foreground" />
            <p className="mt-3 font-medium">No analyses yet</p>
            <p className="text-sm text-muted-foreground">Results appear here after you analyze an image.</p>
            <Button asChild variant="gradient" className="mt-4">
              <Link to="/analyze">Analyze an image</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((h) => (
            <Card key={h.id} className="overflow-hidden">
              <button className="block w-full" onClick={() => setOpen(h)} aria-label={`Open analysis ${h.fileName}`}>
                <img src={h.overlay} alt="Water overlay" className="aspect-[4/3] w-full object-cover" />
              </button>
              <CardContent className="space-y-2 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{h.locationLabel || "Unlabelled location"}</p>
                    <p className="truncate text-xs text-muted-foreground">{h.fileName}</p>
                  </div>
                  <RiskBadge risk={h.risk} />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="font-mono font-semibold">{h.waterPercent}% water</span>
                  <span className="text-xs text-muted-foreground">{fmt(h.createdAt)}</span>
                </div>
                <div className="flex gap-2 pt-1">
                  <Button size="sm" variant="secondary" className="flex-1" onClick={() => setOpen(h)}>View</Button>
                  <Button size="sm" variant="ghost" aria-label="Delete analysis" onClick={() => removeAnalysis(h.id)}>
                    <Trash2 />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent className="max-w-3xl">
          {open && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {open.locationLabel || "Unlabelled location"} <RiskBadge risk={open.risk} />
                </DialogTitle>
                <DialogDescription>
                  {open.fileName} · {fmt(open.createdAt)} · {open.waterPercent}% water · {open.method}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  { src: open.original, label: "Original" },
                  { src: open.overlay, label: "Water overlay" },
                  { src: open.mask, label: "Segmentation mask" },
                ].map((i) => (
                  <figure key={i.label}>
                    <img src={i.src} alt={i.label} className="w-full rounded-lg border" />
                    <figcaption className="mt-1 text-center text-xs text-muted-foreground">{i.label}</figcaption>
                  </figure>
                ))}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
