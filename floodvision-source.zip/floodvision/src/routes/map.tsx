import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PageHeader } from "@/components/PageHeader";
import { SampleBadge } from "@/components/SampleBadge";
import { RiskBadge, riskDotClass } from "@/components/RiskBadge";
import { ClientMap } from "@/components/ClientMap";
import { cn } from "@/lib/utils";
import { SAMPLE_LOCATIONS, SAMPLE_MAP_CENTER } from "@/lib/sample-data";
import type { RiskLevel } from "@/lib/flood-analysis";

export const Route = createFileRoute("/map")({
  head: () => ({
    meta: [
      { title: "Flood Risk Map – FloodVision" },
      { name: "description", content: "Interactive OpenStreetMap view of flood zones coloured by High, Medium and Low risk." },
      { property: "og:title", content: "Flood Risk Map – FloodVision" },
      { property: "og:description", content: "Interactive map of flood zones coloured by risk level." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MapPage,
});

const filters: ("All" | RiskLevel)[] = ["All", "High", "Medium", "Low"];

function MapPage() {
  const [filter, setFilter] = useState<"All" | RiskLevel>("All");
  const [selected, setSelected] = useState<string | null>(null);
  const shown = SAMPLE_LOCATIONS.filter((l) => filter === "All" || l.risk === filter).sort((a, b) => a.priority - b.priority);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-10">
      <PageHeader
        eyebrow="Map"
        title="Flood risk map"
        description="Sample zones placed on OpenStreetMap to show how analyzed areas would be reviewed. Click a zone for details."
        actions={<SampleBadge label="Sample locations — not real data" />}
      />

      <div className="mb-4 flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-sm font-medium transition",
              filter === f ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-secondary",
            )}
          >
            {f !== "All" && <span className={cn("size-2 rounded-full", riskDotClass(f))} />}
            {f === "All" ? "All zones" : `${f} risk`}
          </button>
        ))}
      </div>

      <div className="grid items-start gap-6 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          <ClientMap locations={shown} center={SAMPLE_MAP_CENTER} selectedId={selected} onSelect={setSelected} />
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Zones ({shown.length})</CardTitle>
            <CardDescription>Sorted by response priority.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {shown.map((l) => (
              <button
                key={l.id}
                onClick={() => setSelected(l.id)}
                className={cn(
                  "w-full rounded-lg border p-3 text-left transition",
                  selected === l.id ? "border-primary bg-accent" : "hover:bg-secondary",
                )}
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-semibold">
                    <span className="mr-1 font-mono text-primary">#{l.priority}</span> {l.name}
                  </p>
                  <RiskBadge risk={l.risk} />
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {l.waterCoverage}% water · {l.note}
                </p>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
