import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ImagePlus, Loader2, ScanSearch, Trash2, Info, Cpu, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/PageHeader";
import { RiskBadge } from "@/components/RiskBadge";
import { RiskIndicators } from "@/components/RiskIndicators";
import { cn } from "@/lib/utils";
import { analyzeImage, validateImageFile, type AnalysisResult, type DetectionMode } from "@/lib/flood-analysis";
import { addAnalysis } from "@/lib/history-store";
import sampleImg from "@/assets/hero-flood-aerial.jpg";

export const Route = createFileRoute("/analyze")({
  head: () => ({
    meta: [
      { title: "Analyze Drone Image – FloodVision" },
      { name: "description", content: "Upload a JPG or PNG drone image and estimate how much of the area is under water." },
      { property: "og:title", content: "Analyze Drone Image – FloodVision" },
      { property: "og:description", content: "Upload a drone image and estimate flood water coverage and risk." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AnalyzePage,
});

const modes: { value: DetectionMode; label: string; hint: string }[] = [
  { value: "auto", label: "Auto", hint: "Muddy and clear water" },
  { value: "muddy", label: "Muddy water", hint: "Brown floodwater" },
  { value: "clear", label: "Clear water", hint: "Blue / dark water" },
];

interface Selected {
  src: string;
  name: string;
  size: number | null;
  isSample: boolean;
}

function AnalyzePage() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [selected, setSelected] = useState<Selected | null>(null);
  const [location, setLocation] = useState("");
  const [mode, setMode] = useState<DetectionMode>("auto");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [view, setView] = useState<"overlay" | "mask" | "original">("overlay");
  const [dragging, setDragging] = useState(false);

  useEffect(() => {
    return () => {
      if (selected && !selected.isSample) URL.revokeObjectURL(selected.src);
    };
  }, [selected]);

  function pickFile(file: File | undefined) {
    if (!file) return;
    const err = validateImageFile(file);
    if (err) {
      toast.error(err);
      return;
    }
    setSelected({ src: URL.createObjectURL(file), name: file.name, size: file.size, isSample: false });
    setResult(null);
  }

  function useSample() {
    setSelected({ src: sampleImg, name: "sample-flood-aerial.jpg", size: null, isSample: true });
    setResult(null);
  }

  async function run() {
    if (!selected) return;
    setBusy(true);
    try {
      const r = await analyzeImage(selected.src, { fileName: selected.name, locationLabel: location, mode });
      setResult(r);
      setView("overlay");
      addAnalysis(r);
      toast.success("Analysis complete and saved to history");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Analysis failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-10">
      <PageHeader
        eyebrow="Image analysis"
        title="Analyze a drone image"
        description="Upload an aerial photo of the affected area. FloodVision estimates which parts look like floodwater and how much of the frame they cover."
      />

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>1. Upload image</CardTitle>
            <CardDescription>JPG or PNG, up to 15 MB.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragging(false);
                pickFile(e.dataTransfer.files[0]);
              }}
              className={cn(
                "relative grid w-full place-items-center overflow-hidden rounded-xl border-2 border-dashed bg-secondary/50 text-center transition",
                dragging ? "border-primary bg-accent" : "border-input hover:border-primary/60",
                selected ? "aspect-[4/3]" : "py-12",
              )}
            >
              {selected ? (
                <img src={selected.src} alt="Uploaded drone preview" className="absolute inset-0 size-full object-cover" />
              ) : (
                <div className="px-4">
                  <ImagePlus className="mx-auto size-10 text-primary" />
                  <p className="mt-3 font-medium">Click or drop an image here</p>
                  <p className="text-sm text-muted-foreground">Accepted: .jpg, .jpeg, .png</p>
                </div>
              )}
            </button>
            <input
              ref={inputRef}
              type="file"
              accept="image/jpeg,image/png"
              className="hidden"
              onChange={(e) => {
                pickFile(e.target.files?.[0]);
                e.target.value = "";
              }}
            />

            {selected ? (
              <div className="flex items-center justify-between gap-2 rounded-lg bg-secondary px-3 py-2 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-medium">{selected.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {selected.isSample ? "Generated sample image for demo" : `${((selected.size ?? 0) / 1024 / 1024).toFixed(2)} MB`}
                  </p>
                </div>
                <Button variant="ghost" size="icon" aria-label="Remove image" onClick={() => { setSelected(null); setResult(null); }}>
                  <Trash2 />
                </Button>
              </div>
            ) : (
              <Button variant="outline" className="w-full" onClick={useSample}>
                No drone image? Try a sample image
              </Button>
            )}

            <div className="space-y-2">
              <Label htmlFor="loc">Location label (optional)</Label>
              <Input id="loc" placeholder="e.g. Ward 12 near river bridge" value={location} onChange={(e) => setLocation(e.target.value)} maxLength={80} />
              <p className="text-xs text-muted-foreground">Typed by you — FloodVision does not read GPS from images.</p>
            </div>

            <div className="space-y-2">
              <Label>Water type</Label>
              <div className="grid grid-cols-3 gap-2">
                {modes.map((m) => (
                  <button
                    key={m.value}
                    type="button"
                    onClick={() => setMode(m.value)}
                    className={cn(
                      "rounded-lg border px-2 py-2 text-left transition",
                      mode === m.value ? "border-primary bg-accent text-accent-foreground" : "hover:bg-secondary",
                    )}
                  >
                    <p className="text-sm font-semibold">{m.label}</p>
                    <p className="text-[11px] text-muted-foreground">{m.hint}</p>
                  </button>
                ))}
              </div>
            </div>

            <Button variant="gradient" size="xl" className="w-full" disabled={!selected || busy} onClick={run}>
              {busy ? <Loader2 className="animate-spin" /> : <ScanSearch />}
              {busy ? "Analyzing…" : "Analyze Flood"}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6 lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <CardTitle>2. Analysis results</CardTitle>
                {result && <RiskBadge risk={result.risk} className="text-sm" />}
              </div>
              <CardDescription>Water estimate and flood segmentation image appear here after analysis.</CardDescription>
            </CardHeader>
            <CardContent>
              {!result ? (
                <div className="grid min-h-72 place-items-center rounded-xl border border-dashed bg-secondary/40 grid-water p-6 text-center">
                  <div>
                    <ScanSearch className="mx-auto size-10 text-muted-foreground" />
                    <p className="mt-3 font-medium">No results yet</p>
                    <p className="text-sm text-muted-foreground">Upload an image and press Analyze Flood.</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-5">
                  <div className="flex gap-1 rounded-lg bg-secondary p-1">
                    {(["overlay", "mask", "original"] as const).map((v) => (
                      <button
                        key={v}
                        onClick={() => setView(v)}
                        className={cn(
                          "flex-1 rounded-md px-3 py-1.5 text-sm font-medium capitalize transition",
                          view === v ? "bg-card text-primary shadow-card" : "text-muted-foreground",
                        )}
                      >
                        {v === "overlay" ? "Water overlay" : v === "mask" ? "Segmentation mask" : "Original"}
                      </button>
                    ))}
                  </div>
                  <img
                    src={view === "overlay" ? result.overlay : view === "mask" ? result.mask : result.original}
                    alt={`${view} view of analyzed image`}
                    className="w-full rounded-xl border object-contain"
                  />
                  <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                    <Metric label="Water coverage" value={`${result.waterPercent}%`} />
                    <Metric label="Risk level" value={result.risk} />
                    <Metric label="Image size" value={`${result.width}×${result.height}`} />
                    <Metric label="Water type" value={modes.find((m) => m.value === result.mode)?.label ?? ""} />
                  </div>
                  <div className="flex gap-2 rounded-lg border border-primary/20 bg-secondary p-3 text-xs text-secondary-foreground">
                    <Info className="size-4 shrink-0 text-primary" />
                    <p>
                      <strong>Method:</strong> {result.method}. Pixels coloured like floodwater are highlighted in blue.
                      Roofs, soil or shadows of similar colour can be counted by mistake — treat this as a rough estimate
                      and confirm on the ground.
                    </p>
                  </div>
                  <Button asChild variant="outline" size="sm">
                    <Link to="/history"><History /> View in history</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Cpu className="size-5 text-primary" />
                <CardTitle>AI model results</CardTitle>
              </div>
              <CardDescription>Reserved for a trained flood segmentation model.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                No AI model is connected yet, so no AI predictions are shown. When one is added, its segmentation
                image and confidence scores will appear in this card next to the colour-based estimate.
              </div>
            </CardContent>
          </Card>

          <div>
            <p className="mb-2 text-sm font-semibold">How risk levels are set</p>
            <RiskIndicators />
          </div>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-secondary p-3">
      <p className="font-mono text-lg font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
