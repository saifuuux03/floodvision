import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BarChart3, Map, ShieldAlert, Upload, ScanSearch, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import heroImg from "@/assets/hero-flood-aerial.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FloodVision – Drone-Powered Flood Mapping" },
      { name: "description", content: "Upload drone images of flooded areas, estimate water coverage, rate flood risk and plan response priorities on a map." },
      { property: "og:title", content: "FloodVision – Drone-Powered Flood Mapping" },
      { property: "og:description", content: "Turn drone images into flood coverage estimates, risk levels and priority maps." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const steps = [
  { icon: Upload, title: "Upload drone image", text: "Add a JPG or PNG aerial photo of the affected area." },
  { icon: ScanSearch, title: "Analyze flood", text: "FloodVision marks water-coloured areas and measures how much of the frame is covered." },
  { icon: ShieldAlert, title: "Rate the risk", text: "Coverage is turned into a High, Medium or Low risk level." },
  { icon: Map, title: "Plan response", text: "Review zones on the map and the priority table to decide where to go first." },
];

const features = [
  { icon: BarChart3, title: "Dashboard", text: "Flood statistics and charts at a glance.", to: "/dashboard" as const },
  { icon: Map, title: "Interactive map", text: "Zones on OpenStreetMap, coloured by risk.", to: "/map" as const },
  { icon: History, title: "Analysis history", text: "Every analysis you run is saved in this browser.", to: "/history" as const },
];

function Home() {
  return (
    <>
      <section className="relative overflow-hidden">
        <img src={heroImg} alt="Aerial view of a flooded town" className="absolute inset-0 size-full object-cover" width={1312} height={1199} />
        <div className="absolute inset-0 bg-hero-gradient" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 md:px-6 md:py-32">
          <p className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/30 bg-primary-foreground/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-primary-foreground">
            Disaster response · Drone imagery
          </p>
          <h1 className="mt-6 max-w-3xl text-4xl font-bold leading-[1.05] text-primary-foreground md:text-6xl">
            See the flood from above. Decide where help goes first.
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-primary-foreground/85">
            FloodVision turns drone photos into water-coverage estimates, risk levels and a priority map, so
            response teams can act on a clear picture instead of guesswork.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="hero" size="xl">
              <Link to="/analyze">
                Analyze an image <ArrowRight />
              </Link>
            </Button>
            <Button asChild variant="heroOutline" size="xl">
              <Link to="/dashboard">Open dashboard</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6">
        <h2 className="text-2xl font-bold md:text-3xl">How it works</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <Card key={s.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <span className="grid size-11 place-items-center rounded-lg bg-secondary text-primary">
                    <s.icon className="size-5" />
                  </span>
                  <span className="font-mono text-sm text-muted-foreground">0{i + 1}</span>
                </div>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="border-y bg-card grid-water">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-16 md:grid-cols-3 md:px-6">
          {features.map((f) => (
            <Link key={f.title} to={f.to} className="group rounded-xl border bg-card p-6 shadow-card transition hover:-translate-y-0.5 hover:border-primary/40">
              <f.icon className="size-6 text-primary" />
              <h3 className="mt-3 text-lg font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                Open <ArrowRight className="size-4 transition group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6">
        <Card className="border-primary/20 bg-secondary">
          <CardContent className="p-6 md:p-8">
            <h2 className="text-xl font-bold">Honest by design</h2>
            <ul className="mt-3 grid gap-2 text-sm text-secondary-foreground md:grid-cols-3">
              <li>• Water detection is a simple colour-based estimate that runs in your browser — not an AI model.</li>
              <li>• Map zones, dashboard figures and the priority table use clearly labelled sample data.</li>
              <li>• No live drone feeds, GPS tracking or rescue detections are shown or simulated.</li>
            </ul>
          </CardContent>
        </Card>
      </section>
    </>
  );
}
