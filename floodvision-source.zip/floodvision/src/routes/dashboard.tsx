import { createFileRoute, Link } from "@tanstack/react-router";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Droplets, MapPin, Users, AlertTriangle, ScanSearch } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/PageHeader";
import { SampleBadge } from "@/components/SampleBadge";
import { RiskIndicators } from "@/components/RiskIndicators";
import { PriorityTable } from "@/components/PriorityTable";
import { RiskBadge } from "@/components/RiskBadge";
import { SAMPLE_LOCATIONS, SAMPLE_TREND, riskCounts } from "@/lib/sample-data";
import { useHistory } from "@/lib/history-store";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Flood Dashboard – FloodVision" },
      { name: "description", content: "Flood statistics, risk levels, charts and priority locations in one dashboard." },
      { property: "og:title", content: "Flood Dashboard – FloodVision" },
      { property: "og:description", content: "Flood statistics, risk levels, charts and priority locations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const tooltipStyle = { borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", fontSize: 12 };

function Dashboard() {
  const history = useHistory();
  const counts = riskCounts(SAMPLE_LOCATIONS);
  const avgCoverage = Math.round(SAMPLE_LOCATIONS.reduce((s, l) => s + l.waterCoverage, 0) / SAMPLE_LOCATIONS.length);
  const residentsAtRisk = SAMPLE_LOCATIONS.filter((l) => l.risk !== "Low").reduce((s, l) => s + l.population, 0);
  const pieData = [
    { name: "High", value: counts.High, color: "var(--risk-high)" },
    { name: "Medium", value: counts.Medium, color: "var(--risk-medium)" },
    { name: "Low", value: counts.Low, color: "var(--risk-low)" },
  ];
  const barData = SAMPLE_LOCATIONS.map((l) => ({ zone: `Zone ${l.id}`, coverage: l.waterCoverage, risk: l.risk }));
  const riskColor = { High: "var(--risk-high)", Medium: "var(--risk-medium)", Low: "var(--risk-low)" } as const;

  const stats = [
    { label: "Zones monitored", value: SAMPLE_LOCATIONS.length, icon: MapPin },
    { label: "High-risk zones", value: counts.High, icon: AlertTriangle },
    { label: "Avg. water coverage", value: `${avgCoverage}%`, icon: Droplets },
    { label: "Residents in Medium/High zones", value: residentsAtRisk.toLocaleString("en-IN"), icon: Users },
  ];

  const recent = history.slice(0, 5);
  const userAvg = history.length ? Math.round((history.reduce((s, h) => s + h.waterPercent, 0) / history.length) * 10) / 10 : null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-10">
      <PageHeader
        eyebrow="Overview"
        title="Flood dashboard"
        description="Demonstration figures for a sample flood event, plus a summary of the images you have analyzed."
        actions={
          <Button asChild variant="gradient">
            <Link to="/analyze"><ScanSearch /> Analyze image</Link>
          </Button>
        }
      />

      <div className="mb-3 flex items-center gap-2">
        <h2 className="text-lg font-semibold">Sample event</h2>
        <SampleBadge />
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-5">
              <s.icon className="size-5 text-primary" />
              <p className="mt-3 font-mono text-2xl font-semibold md:text-3xl">{s.value}</p>
              <p className="mt-1 text-xs text-muted-foreground md:text-sm">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6">
        <RiskIndicators counts={counts} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between gap-2">
              <CardTitle>Water coverage by zone</CardTitle>
              <SampleBadge />
            </div>
            <CardDescription>Share of each zone's surveyed area covered by water.</CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} margin={{ left: -16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="zone" tick={{ fontSize: 12, fill: "var(--muted-foreground)" }} />
                <YAxis unit="%" tick={{ fontSize: 12, fill: "var(--muted-foreground)" }} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--secondary)" }} />
                <Bar dataKey="coverage" name="Water coverage" unit="%" radius={[6, 6, 0, 0]}>
                  {barData.map((d) => (
                    <Cell key={d.zone} fill={riskColor[d.risk]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-2">
              <CardTitle>Risk distribution</CardTitle>
              <SampleBadge />
            </div>
            <CardDescription>Number of zones per risk level.</CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>
                  {pieData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
            <div className="-mt-4 flex justify-center gap-4 text-xs">
              {pieData.map((d) => (
                <span key={d.name} className="flex items-center gap-1.5">
                  <span className="size-2.5 rounded-full" style={{ background: d.color }} />
                  {d.name} ({d.value})
                </span>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between gap-2">
              <CardTitle>Flood extent trend</CardTitle>
              <SampleBadge />
            </div>
            <CardDescription>Average water coverage across all zones over a 7-day sample event.</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={SAMPLE_TREND} margin={{ left: -16 }}>
                <defs>
                  <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: "var(--muted-foreground)" }} />
                <YAxis unit="%" tick={{ fontSize: 12, fill: "var(--muted-foreground)" }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="coverage" name="Avg. coverage" unit="%" stroke="var(--primary)" strokeWidth={2.5} fill="url(#trendFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your analyses</CardTitle>
            <CardDescription>Real results from images you uploaded in this browser.</CardDescription>
          </CardHeader>
          <CardContent>
            {history.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">
                No analyses yet.
                <Button asChild variant="link" className="block w-full">
                  <Link to="/analyze">Analyze your first image</Link>
                </Button>
              </div>
            ) : (
              <>
                <div className="mb-4 grid grid-cols-2 gap-3">
                  <div className="rounded-lg bg-secondary p-3">
                    <p className="font-mono text-2xl font-semibold">{history.length}</p>
                    <p className="text-xs text-muted-foreground">Images analyzed</p>
                  </div>
                  <div className="rounded-lg bg-secondary p-3">
                    <p className="font-mono text-2xl font-semibold">{userAvg}%</p>
                    <p className="text-xs text-muted-foreground">Avg. water</p>
                  </div>
                </div>
                <ul className="space-y-2">
                  {recent.map((h) => (
                    <li key={h.id} className="flex items-center gap-3">
                      <img src={h.original} alt="" className="size-10 rounded object-cover" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{h.locationLabel || h.fileName}</p>
                        <p className="font-mono text-xs text-muted-foreground">{h.waterPercent}% water</p>
                      </div>
                      <RiskBadge risk={h.risk} />
                    </li>
                  ))}
                </ul>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader>
          <div className="flex items-center justify-between gap-2">
            <CardTitle>Priority locations</CardTitle>
            <SampleBadge />
          </div>
          <CardDescription>Ranked by risk level, water coverage and residents affected.</CardDescription>
        </CardHeader>
        <CardContent>
          <PriorityTable locations={SAMPLE_LOCATIONS} />
        </CardContent>
      </Card>
    </div>
  );
}
