import { describe, expect, it } from "vitest";
import { classifyRisk, computeWaterMask, isWaterPixel, validateImageFile } from "./flood-analysis";

describe("flood risk levels", () => {
  it("is High at 40% water or more", () => {
    expect(classifyRisk(40)).toBe("High");
    expect(classifyRisk(75)).toBe("High");
  });
  it("is Medium from 15% up to under 40%", () => {
    expect(classifyRisk(15)).toBe("Medium");
    expect(classifyRisk(39.9)).toBe("Medium");
  });
  it("is Low under 15%", () => {
    expect(classifyRisk(14.9)).toBe("Low");
    expect(classifyRisk(0)).toBe("Low");
  });
});

describe("water detection", () => {
  it("detects muddy brown water but not green trees or grey roads", () => {
    expect(isWaterPixel(165, 135, 95, "auto")).toBe(true);
    expect(isWaterPixel(60, 110, 50, "auto")).toBe(false);
    expect(isWaterPixel(128, 128, 128, "auto")).toBe(false);
  });
  it("computes the share of water pixels", () => {
    const data = new Uint8ClampedArray([165, 135, 95, 255, 60, 110, 50, 255, 165, 135, 95, 255, 128, 128, 128, 255]);
    expect(computeWaterMask(data, "auto").waterPercent).toBe(50);
  });
});

describe("upload validation", () => {
  it("accepts JPG and PNG only", () => {
    expect(validateImageFile({ type: "image/jpeg", size: 1000 })).toBeNull();
    expect(validateImageFile({ type: "image/png", size: 1000 })).toBeNull();
    expect(validateImageFile({ type: "image/gif", size: 1000 })).not.toBeNull();
  });
});
