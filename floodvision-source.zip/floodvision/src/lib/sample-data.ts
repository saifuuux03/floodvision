import type { RiskLevel } from "./flood-analysis";

/**
 * DEMONSTRATION DATA ONLY.
 * These zones, coordinates and figures are invented for the prototype. They are not
 * real flood observations, drone detections or rescue information.
 */

export interface SampleLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  risk: RiskLevel;
  waterCoverage: number; // percent of surveyed area
  population: number; // estimated residents in zone
  priority: number; // 1 = highest
  note: string;
}

export const SAMPLE_LOCATIONS: SampleLocation[] = [
  { id: "A", name: "Sample Zone A – Riverside Ward", lat: 26.1905, lng: 91.7362, risk: "High", waterCoverage: 68, population: 4200, priority: 1, note: "Low-lying homes near river bank" },
  { id: "B", name: "Sample Zone B – Market Area", lat: 26.1832, lng: 91.7511, risk: "High", waterCoverage: 52, population: 3100, priority: 2, note: "Main access road under water" },
  { id: "C", name: "Sample Zone C – School Campus", lat: 26.1718, lng: 91.7605, risk: "Medium", waterCoverage: 34, population: 1500, priority: 3, note: "Possible relief shelter site" },
  { id: "D", name: "Sample Zone D – Farmland East", lat: 26.1951, lng: 91.7804, risk: "Medium", waterCoverage: 29, population: 800, priority: 4, note: "Crop fields partly submerged" },
  { id: "E", name: "Sample Zone E – Hospital Road", lat: 26.1653, lng: 91.7432, risk: "Medium", waterCoverage: 21, population: 2600, priority: 5, note: "Keep ambulance route clear" },
  { id: "F", name: "Sample Zone F – Hillside Colony", lat: 26.1559, lng: 91.7698, risk: "Low", waterCoverage: 8, population: 1900, priority: 6, note: "Elevated ground, minor pooling" },
  { id: "G", name: "Sample Zone G – Rail Yard", lat: 26.1782, lng: 91.7258, risk: "Low", waterCoverage: 11, population: 400, priority: 7, note: "Drainage working" },
];

export const SAMPLE_MAP_CENTER: [number, number] = [26.1775, 91.7531];

export const SAMPLE_TREND = [
  { day: "Day 1", coverage: 12 },
  { day: "Day 2", coverage: 19 },
  { day: "Day 3", coverage: 31 },
  { day: "Day 4", coverage: 44 },
  { day: "Day 5", coverage: 39 },
  { day: "Day 6", coverage: 33 },
  { day: "Day 7", coverage: 26 },
];

export function riskCounts(list: { risk: RiskLevel }[]) {
  return {
    High: list.filter((l) => l.risk === "High").length,
    Medium: list.filter((l) => l.risk === "Medium").length,
    Low: list.filter((l) => l.risk === "Low").length,
  };
}
