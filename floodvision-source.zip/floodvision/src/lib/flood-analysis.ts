/**
 * In-browser flood water estimation.
 *
 * This is a transparent colour heuristic, NOT an AI model. It marks pixels whose
 * colour looks like floodwater (muddy brown or clear blue) and reports the share
 * of the frame covered. Results must always be labelled as an estimate.
 */

export type RiskLevel = "High" | "Medium" | "Low";
export type DetectionMode = "auto" | "muddy" | "clear";

/** Share of the frame covered by detected water (percent) that triggers each level. */
export const RISK_THRESHOLDS = { high: 40, medium: 15 } as const;

export const METHOD_LABEL = "Colour-based water estimate (in-browser, not AI)";

export function classifyRisk(waterPercent: number): RiskLevel {
  if (waterPercent >= RISK_THRESHOLDS.high) return "High";
  if (waterPercent >= RISK_THRESHOLDS.medium) return "Medium";
  return "Low";
}

function isMuddyWater(r: number, g: number, b: number): boolean {
  const brightness = (r + g + b) / 3;
  return (
    r >= g &&
    g > b &&
    r - b >= 25 &&
    r - b <= 115 &&
    g - b >= 12 &&
    r - g <= 45 &&
    brightness >= 70 &&
    brightness <= 215
  );
}

function isClearWater(r: number, g: number, b: number): boolean {
  const brightness = (r + g + b) / 3;
  return b > r + 15 && b >= g - 10 && brightness >= 35 && brightness <= 220;
}

export function isWaterPixel(r: number, g: number, b: number, mode: DetectionMode): boolean {
  if (mode === "muddy") return isMuddyWater(r, g, b);
  if (mode === "clear") return isClearWater(r, g, b);
  return isMuddyWater(r, g, b) || isClearWater(r, g, b);
}

export interface MaskResult {
  mask: Uint8Array;
  waterPixels: number;
  totalPixels: number;
  waterPercent: number;
}

/** Works on RGBA pixel data (as returned by canvas getImageData). */
export function computeWaterMask(data: Uint8ClampedArray, mode: DetectionMode): MaskResult {
  const totalPixels = Math.floor(data.length / 4);
  const mask = new Uint8Array(totalPixels);
  let waterPixels = 0;
  for (let i = 0; i < totalPixels; i++) {
    const o = i * 4;
    const r = data[o] ?? 0;
    const g = data[o + 1] ?? 0;
    const b = data[o + 2] ?? 0;
    if (isWaterPixel(r, g, b, mode)) {
      mask[i] = 1;
      waterPixels++;
    }
  }
  const waterPercent = totalPixels === 0 ? 0 : (waterPixels / totalPixels) * 100;
  return { mask, waterPixels, totalPixels, waterPercent };
}

export const ACCEPTED_TYPES = ["image/jpeg", "image/png"] as const;
export const MAX_FILE_MB = 15;

export function validateImageFile(file: { type: string; size: number }): string | null {
  if (!(ACCEPTED_TYPES as readonly string[]).includes(file.type)) {
    return "Only JPG and PNG images are supported.";
  }
  if (file.size > MAX_FILE_MB * 1024 * 1024) {
    return `Image is larger than ${MAX_FILE_MB} MB.`;
  }
  return null;
}

export interface AnalysisResult {
  id: string;
  createdAt: string;
  fileName: string;
  locationLabel: string;
  mode: DetectionMode;
  waterPercent: number;
  risk: RiskLevel;
  width: number;
  height: number;
  method: string;
  /** Small JPEG data URLs so results fit in browser storage. */
  original: string;
  overlay: string;
  mask: string;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read this image."));
    img.src = src;
  });
}

function canvasOf(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("Canvas is not supported in this browser.");
  return { c, ctx };
}

/** Browser-only: call from an event handler. */
export async function analyzeImage(
  src: string,
  opts: { fileName: string; locationLabel: string; mode: DetectionMode },
): Promise<AnalysisResult> {
  const img = await loadImage(src);
  const maxSide = 640;
  const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));

  const { c: base, ctx } = canvasOf(w, h);
  ctx.drawImage(img, 0, 0, w, h);
  const pixels = ctx.getImageData(0, 0, w, h);
  const { mask, waterPercent } = computeWaterMask(pixels.data, opts.mode);

  const { c: overlayC, ctx: octx } = canvasOf(w, h);
  octx.drawImage(base, 0, 0);
  const over = octx.getImageData(0, 0, w, h);
  const { c: maskC, ctx: mctx } = canvasOf(w, h);
  const maskImg = mctx.createImageData(w, h);
  for (let i = 0; i < mask.length; i++) {
    const o = i * 4;
    if (mask[i]) {
      // Tint detected water cyan-blue on the overlay.
      over.data[o] = Math.round((over.data[o] ?? 0) * 0.35 + 0 * 0.65);
      over.data[o + 1] = Math.round((over.data[o + 1] ?? 0) * 0.35 + 170 * 0.65);
      over.data[o + 2] = Math.round((over.data[o + 2] ?? 0) * 0.35 + 255 * 0.65);
      maskImg.data[o] = 30;
      maskImg.data[o + 1] = 144;
      maskImg.data[o + 2] = 255;
    } else {
      maskImg.data[o] = 12;
      maskImg.data[o + 1] = 20;
      maskImg.data[o + 2] = 40;
    }
    maskImg.data[o + 3] = 255;
  }
  octx.putImageData(over, 0, 0);
  mctx.putImageData(maskImg, 0, 0);

  return {
    id: `${Date.now()}-${Math.round(Math.random() * 1e6)}`,
    createdAt: new Date().toISOString(),
    fileName: opts.fileName,
    locationLabel: opts.locationLabel.trim(),
    mode: opts.mode,
    waterPercent: Math.round(waterPercent * 10) / 10,
    risk: classifyRisk(waterPercent),
    width: img.naturalWidth,
    height: img.naturalHeight,
    method: METHOD_LABEL,
    original: base.toDataURL("image/jpeg", 0.75),
    overlay: overlayC.toDataURL("image/jpeg", 0.75),
    mask: maskC.toDataURL("image/png"),
  };
}
