import { useSyncExternalStore } from "react";
import type { AnalysisResult } from "./flood-analysis";

const KEY = "floodvision.history.v1";
const MAX_ITEMS = 12;
const EMPTY: AnalysisResult[] = [];

let cache: AnalysisResult[] | null = null;
const listeners = new Set<() => void>();

function read(): AnalysisResult[] {
  if (cache) return cache;
  try {
    const raw = window.localStorage.getItem(KEY);
    cache = raw ? (JSON.parse(raw) as AnalysisResult[]) : [];
  } catch {
    cache = [];
  }
  return cache;
}

function write(items: AnalysisResult[]) {
  let list = items.slice(0, MAX_ITEMS);
  // Drop oldest entries if the browser storage quota is hit.
  while (list.length > 0) {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(list));
      break;
    } catch {
      list = list.slice(0, -1);
    }
  }
  if (list.length === 0) window.localStorage.removeItem(KEY);
  cache = list;
  listeners.forEach((l) => l());
}

export function addAnalysis(item: AnalysisResult) {
  write([item, ...read()]);
}
export function removeAnalysis(id: string) {
  write(read().filter((i) => i.id !== id));
}
export function clearHistory() {
  write([]);
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY) {
      cache = null;
      cb();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(cb);
    window.removeEventListener("storage", onStorage);
  };
}

export function useHistory(): AnalysisResult[] {
  return useSyncExternalStore(subscribe, read, () => EMPTY);
}
